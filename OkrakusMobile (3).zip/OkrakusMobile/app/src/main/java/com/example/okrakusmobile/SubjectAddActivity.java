package com.example.okrakusmobile;

import android.content.DialogInterface;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class SubjectAddActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(SubjectAddActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }
    public void addSubject(Connection cnx, String nazwa, String typ ) {
        try {
            Statement stx = cnx.createStatement();
            int insertCount = stx.executeUpdate("INSERT INTO PRZEDMIOTY VALUES('" + nazwa + "','" + typ +  "');");
            message("Dodano przedmiot");
        } catch (SQLException e) {
            message("Wystąpił błąd");
        }
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_subject);
        findViewById(R.id.addSubject_add_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            Connection cnx = MainActivity.cnx;
                            Spinner spinnerTyp = (Spinner) findViewById(R.id.addSubject_Types_Spinner);
                            String typ = spinnerTyp.getSelectedItem().toString();
                            //Spinner nazwaInput = (Spinner) findViewById(R.id.ClassAdd_Wyp_Combo);
                           // String nazwa = nazwaInput.getSelectedItem().toString();
                           // addSubject(cnx,nazwa,typ);
                    }
                });


    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
