package com.example.okrakusmobile;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.os.StrictMode;
import android.view.View;
import android.view.Menu;
import android.view.MenuItem;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MainActivity extends AppCompatActivity {

    public static Connection cnx=null;
    public static int connection=0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        if(connection==0)cnx= connector();
        connection++;
        findViewById(R.id.MainMenu_Students_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(MainActivity.this, StudentsActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        findViewById(R.id.MainMenu_Class_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(MainActivity.this, ClassActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        findViewById(R.id.MainMenu_Subjects_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(MainActivity.this, SubjectsActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        findViewById(R.id.MainMenu_Teachers_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(MainActivity.this, TeachersActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        findViewById(R.id.MainMenu_Close_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
    }
    public void message(String wiadomosc){
    AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this).create();
            alertDialog.setTitle("Alert");
            alertDialog.setMessage(wiadomosc);
            alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
            new DialogInterface.OnClickListener() {
                public void onClick(DialogInterface dialog, int which) {
                    dialog.dismiss();
                }


    });
        alertDialog.show();
    }


    public  Connection connector(){

        java.sql.Connection cnx = null;
        String driver = "com.mysql.jdbc.Driver";
        String url = "jdbc:mysql://34.89.209.127:3306/okrakus";
        String user = "admin_okrakus";
        String password = "javaprojekt";

        StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
        StrictMode.setThreadPolicy(policy);

        try {
            Class.forName(driver);
            cnx = DriverManager.getConnection(url, user, password);
            message("Udalo sie polaczyc");
            return cnx;
        } catch (Exception e) {

            message("Nie udalo sie polaczyc");
            return null;
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

}
