package com.example.okrakusmobile;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

public class ClassForSubjectActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(ClassForSubjectActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }
    public void ShowSubjectsAndGroups(Connection cnx) {
        String GroupLiczba="";
        String subjectName="";
        try {
            Statement stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT STU_GRU_ID,COUNT(STU_OSO_ID) AS LICZBA FROM STUDENCI_PRZYDZIAL GROUP BY STUDENCI_PRZYDZIAL.STU_GRU_ID");
            Spinner spinner = (Spinner)findViewById(R.id.classForSuject_Groups_Spinner);
            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spinnerAdapter);
            while (rs.next()) {
                GroupLiczba=rs.getInt("STU_GRU_ID")+" -  Liczba studentów :"+rs.getInt("Liczba");
                spinnerAdapter.add(GroupLiczba);
                spinnerAdapter.notifyDataSetChanged();

            }
            rs = stmt.executeQuery("SELECT PRZ_NAZWA,PRZ_TYP FROM PRZEDMIOTY");
            Spinner spinner2 = (Spinner)findViewById(R.id.classForSubject_Subject_Spinner2);
            ArrayAdapter<String> spinnerAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
            spinnerAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner2.setAdapter(spinnerAdapter2);
            while (rs.next()) {
                subjectName=rs.getString("PRZ_NAZWA")+"("+rs.getString("PRZ_TYP")+")";
                spinnerAdapter2.add(subjectName);
                spinnerAdapter2.notifyDataSetChanged();
            }


        } catch (SQLException e) {
            message("Wystąpił błąd");
        }
    }

    public void ShowClasses(Connection cnx){

        TableLayout tl = (TableLayout) findViewById(R.id.ClassForSubject_TableLayout);
        int childCount = tl.getChildCount();
        if (childCount > 1) {
           tl.removeViews(1, childCount - 1);
       }








        Spinner spinnerPrzedmiot = (Spinner) findViewById(R.id.classForSubject_Subject_Spinner2);
        String NazwaPrzedmiotu = spinnerPrzedmiot.getSelectedItem().toString();
        String TypPrzedmiotu=NazwaPrzedmiotu.substring((NazwaPrzedmiotu.length()-4), (NazwaPrzedmiotu.length()-3));

        Spinner spinnerLiczba = (Spinner) findViewById(R.id.classForSuject_Groups_Spinner);
        String LiczbaStudentow = spinnerLiczba.getSelectedItem().toString();
        LiczbaStudentow=LiczbaStudentow.substring(LiczbaStudentow.indexOf(":")+1,LiczbaStudentow.length());


        int LiczbaStudentowInt = Integer.parseInt(LiczbaStudentow);
        try {
            Statement stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT * FROM SALE WHERE SAL_TYP='"+TypPrzedmiotu+"' AND SAL_LICZBA_MIEJSC>="+LiczbaStudentowInt+";");
            if (rs.first()==false){
                message("Brak sali pasującej do podanych kryteriów");
                return;
            }
            rs.beforeFirst();
            while (rs.next()) {
                String wyp="Tak";
                if(rs.getInt("SAL_DODATKOWE_WYP")==0) wyp="Nie";
                String typSali=rs.getString("SAL_TYP");
                TableRow tr = new TableRow(this);
                TextView td0 = new TextView(this);
                TextView td1 = new TextView(this);
                TextView td2 = new TextView(this);
                TextView td3 = new TextView(this);

                td0.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                td1.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                td2.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                td3.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

                td0.setText(String.valueOf(rs.getInt("SAL_ID")));
                td1.setText(rs.getString("SAL_TYP"));
                td2.setText(String.valueOf(rs.getInt("SAL_LICZBA_MIEJSC")));
                td3.setText(wyp);

                tr.addView(td0);
                tr.addView(td1);
                tr.addView(td2);
                tr.addView(td3);

                tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                tl.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));
            }
        } catch (SQLException e) {
            message( "Wystąpił problem");
        }
    }




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activityclassforsubject2);
        Connection cnx = MainActivity.cnx;
        ShowSubjectsAndGroups(cnx);

        findViewById(R.id.classForSubject_Show_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        ShowClasses(MainActivity.cnx);

                    }
                });
        findViewById(R.id.mainMenu_Close_Button3).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.students_MainMenu_Button2).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(ClassForSubjectActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });


    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
