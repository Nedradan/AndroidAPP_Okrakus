package com.example.okrakusmobile;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class SubjectAddActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(SubjectAddActivity.this).create();
        alertDialog.setTitle("");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }
    public void addSubject(Connection cnx, String nazwa, String typ ) {
        try {
            Statement stx = cnx.createStatement();
            int insertCount = stx.executeUpdate("INSERT INTO PRZEDMIOTY (PRZ_NAZWA, PRZ_TYP) VALUES('" + nazwa + "','" + typ +  "');");
            message("Dodano przedmiot");
        } catch (SQLException e) {
            message("Wystąpił błąd");
        }
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_subject);
        findViewById(R.id.addSubject_add_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            Connection cnx = MainActivity.cnx;
                            Spinner spinnerTyp = (Spinner) findViewById(R.id.addSubject_Types_Spinner);
                            String typ = spinnerTyp.getSelectedItem().toString();
                            EditText nazwaInput = (EditText) findViewById(R.id.SubjectAdd_Name_Input);
                            if(nazwaInput.length()!=0 && nazwaInput.length()<31) {
                                String nazwa = nazwaInput.getText().toString();
                                addSubject(cnx, nazwa, typ);
                            }
                            else
                                message("Nazwa pusta lub zbyt długa(30 znakow max)");
                    }
                });
        findViewById(R.id.mainMenu_Close_Button3).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.students_MainMenu_Button2).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(SubjectAddActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });


    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
