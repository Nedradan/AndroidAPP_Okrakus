package com.example.okrakusmobile;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SubjectDeleteActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(SubjectDeleteActivity.this).create();
        alertDialog.setTitle("");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }
    public void ShowSubjects(Connection cnx) {
        String subjectName="";
        try {
            Statement stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT PRZ_NAZWA,PRZ_TYP FROM PRZEDMIOTY");
            Spinner spinner2 = (Spinner)findViewById(R.id.deleteSubject_Types_Spinner);
            ArrayAdapter<String> spinnerAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
            spinnerAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner2.setAdapter(spinnerAdapter2);
            while (rs.next()) {
                subjectName=rs.getString("PRZ_NAZWA")+"("+rs.getString("PRZ_TYP")+")";
                spinnerAdapter2.add(subjectName);
                spinnerAdapter2.notifyDataSetChanged();
            }


        } catch (SQLException e) {
            message("Wystąpił błąd");
        }
    }





    public void deleteSubject(Connection cnx, String nazwa, String typ ) {
        try {
            Statement stx = cnx.createStatement();
            int insertCount = stx.executeUpdate("DELETE FROM PRZEDMIOTY WHERE PRZ_NAZWA LIKE '" + nazwa + "' AND PRZ_TYP LIKE '" + typ + "';");
            message("USUNIĘTO przedmiot");
        } catch (SQLException e) {
            message("Wystąpił błąd");
        }
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delete_subject);
        Connection cnx = MainActivity.cnx;
        ShowSubjects(cnx);
        findViewById(R.id.deleteSubject_delete_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            Spinner spinnerPrzedmiot = (Spinner) findViewById(R.id.deleteSubject_Types_Spinner);
                            String NazwaPrzedmiotu = spinnerPrzedmiot.getSelectedItem().toString();
                            String TypPrzedmiotu=NazwaPrzedmiotu.substring((NazwaPrzedmiotu.length()-4), (NazwaPrzedmiotu.length()-1));
                            NazwaPrzedmiotu=NazwaPrzedmiotu.substring(0, (NazwaPrzedmiotu.length()-5));
                            deleteSubject(MainActivity.cnx,NazwaPrzedmiotu,TypPrzedmiotu);
                            ShowSubjects(MainActivity.cnx);

                    }
                });
        findViewById(R.id.mainMenu_Close_Button3).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.students_MainMenu_Button2).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(SubjectDeleteActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });


    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
