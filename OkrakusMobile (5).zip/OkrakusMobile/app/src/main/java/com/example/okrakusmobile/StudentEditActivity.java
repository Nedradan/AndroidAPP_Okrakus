package com.example.okrakusmobile;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentEditActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(StudentEditActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }

    public void ShowStudentGroup(Connection cnx) {
        String NazwaStudenta="";
        String NumerGrupy="";
        String Stypendium="";
        try {
            Statement stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT OSO_ID,OSO_IMIE,OSO_NAZWISKO,OSO_STYPENDIUM FROM OSOBY WHERE OSO_STATUS='Student'");
            Spinner spinner = (Spinner) findViewById(R.id.StudentEdit_Student_Spinner);
            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spinnerAdapter);
            while (rs.next()) {
                Stypendium=rs.getString("OSO_STYPENDIUM");
                if (rs.wasNull())
                    Stypendium="Brak";
                NazwaStudenta = "ID:[" + rs.getInt("OSO_ID") + "] " + rs.getString("OSO_IMIE") + " " + rs.getString("OSO_NAZWISKO")+"[S: "+Stypendium+"]";
                spinnerAdapter.add(NazwaStudenta);
                spinnerAdapter.notifyDataSetChanged();
            }
            rs = stmt.executeQuery("SELECT GRU_ID FROM GRUPY_ST");
            Spinner spinner3 = (Spinner)findViewById(R.id.StudentEdit_Group_Spinner);
            ArrayAdapter<String> spinnerAdapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
            spinnerAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner3.setAdapter(spinnerAdapter3);
            while (rs.next()) {
                NumerGrupy=""+rs.getInt("GRU_ID");
                spinnerAdapter3.add(NumerGrupy);
                spinnerAdapter3.notifyDataSetChanged();
            }
        } catch (SQLException e) {
            message("Błąd polączenia1");
        }
        }

    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager =(InputMethodManager)getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public void editStudent(Connection cnx,int id, String Imie,String Nazwisko,String Stypendium,int GrupaID){
            try {
            if (Stypendium.equals("Brak"))
            {
                Statement stx = cnx.createStatement();
                String sqlQuery="UPDATE OSOBY SET OSO_IMIE ='"+Imie+"',OSO_NAZWISKO='"+Nazwisko+"',OSO_STYPENDIUM=NULL WHERE OSO_ID="+id+";";
                String sqlQuery2="UPDATE STUDENCI_PRZYDZIAL SET STU_GRU_ID="+GrupaID+" WHERE STU_OSO_ID="+id+";";
                stx.executeUpdate(sqlQuery);
                stx.executeUpdate(sqlQuery2);
                }
            else {
                Statement stx = cnx.createStatement();
                String sqlQuery="UPDATE OSOBY SET OSO_IMIE ='"+Imie+"',OSO_NAZWISKO='"+Nazwisko+"',OSO_STYPENDIUM='"+Stypendium+"' WHERE OSO_ID="+id+";";
                String sqlQuery2="UPDATE STUDENCI_PRZYDZIAL SET STU_GRU_ID="+GrupaID+" WHERE STU_OSO_ID="+id+";";
                stx.executeUpdate(sqlQuery);
                stx.executeUpdate(sqlQuery2);
            }
            message("Edytowano Studenta");
        } catch (SQLException e) {
            message("Wystąpił błąd");
        }
    }







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_student);
        ShowStudentGroup(MainActivity.cnx);
        EditText imieInput = (EditText) findViewById(R.id.StudentEdit_Name_Input);
        EditText nazwiskoInput = (EditText) findViewById(R.id.StudentEdit_Surname_Input);
        View l1 = findViewById(R.id.StudentLayout1);
        l1.setVisibility(View.INVISIBLE);
        findViewById(R.id.StudentEdit_Begin_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        View b = findViewById(R.id.StudentEdit_Begin_Button);
                        b.setVisibility(View.INVISIBLE);
                        View l1 = findViewById(R.id.StudentLayout1);
                        l1.setVisibility(View.VISIBLE);

                    }
                });
        findViewById(R.id.StudentEdit_End_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Connection cnx = MainActivity.cnx;
                        Spinner spinnerStypednium= (Spinner) findViewById(R.id.StudentEdit_Money_Spinner);
                        String stypendium = spinnerStypednium.getSelectedItem().toString();
                        EditText imieInput = (EditText) findViewById(R.id.StudentEdit_Name_Input);
                        EditText nazwiskoInput = (EditText) findViewById(R.id.StudentEdit_Surname_Input);
                        Spinner spinnerGrupy = (Spinner) findViewById(R.id.StudentEdit_Group_Spinner);
                        String Grupa = spinnerGrupy.getSelectedItem().toString();
                        int idGrupyINT = Integer.parseInt(Grupa);
                        Spinner spinnerStudent = (Spinner) findViewById(R.id.StudentEdit_Student_Spinner);
                        String Student = spinnerStudent.getSelectedItem().toString();
                        String StudentID=Student.substring(4,Student.indexOf(']'));
                        int idStudentaINT = Integer.parseInt(StudentID);

                        if(imieInput.length()!=0 && imieInput.length()<31) {
                            String imie = imieInput.getText().toString();
                            if(nazwiskoInput.length()!=0 && nazwiskoInput.length()<46)
                            {
                                String nazwisko = nazwiskoInput.getText().toString();
                                editStudent(cnx,idStudentaINT,imie,nazwisko,stypendium,idGrupyINT);
                                ShowStudentGroup(cnx);
                                imieInput.setText("");
                                nazwiskoInput.setText("");
                                View b = findViewById(R.id.StudentEdit_Begin_Button);
                                b.setVisibility(View.VISIBLE);
                                View l1 = findViewById(R.id.StudentLayout1);
                                l1.setVisibility(View.INVISIBLE);
                            }else
                                message("Nazwisko puste lub zbyt długie(30 znakow max)");
                        }
                        else
                            message("Imie puste lub zbyt długie(30 znakow max)");




                    }
                });
        findViewById(R.id.mainMenu_Close_Button3).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.students_MainMenu_Button2).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(StudentEditActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        imieInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });
        nazwiskoInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });



    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
