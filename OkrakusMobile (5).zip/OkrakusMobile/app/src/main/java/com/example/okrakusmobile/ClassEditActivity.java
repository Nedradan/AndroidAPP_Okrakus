package com.example.okrakusmobile;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ClassEditActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(ClassEditActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }
    public void ShowClasses(Connection cnx) {
        String NazwaKlasy="";
        try {
            Statement stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT SAL_ID,SAL_TYP,SAL_LICZBA_MIEJSC,SAL_DODATKOWE_WYP FROM SALE");
            Spinner spinner2 = (Spinner)findViewById(R.id.EditClass_Types_Spinner);
            ArrayAdapter<String> spinnerAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
            spinnerAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner2.setAdapter(spinnerAdapter2);
            while (rs.next()) {
                int idSaliINT=rs.getInt("SAL_ID");
                String idSali=String.valueOf(idSaliINT);
                int iloscMiejscINT=rs.getInt("SAL_LICZBA_MIEJSC");
                String iloscMiejsc=String.valueOf(iloscMiejscINT);
                int wypos=rs.getInt("SAL_DODATKOWE_WYP");
                String dodatkoweWyp="Dodatkowe wyposażenie";
                if(wypos==0)
                    dodatkoweWyp="Brak wyposażenia";
                NazwaKlasy="["+idSali+"] ["+rs.getString("SAL_TYP")+"] [Miejsca: "+iloscMiejsc+"] ["+dodatkoweWyp+"]";
                spinnerAdapter2.add(NazwaKlasy);
                spinnerAdapter2.notifyDataSetChanged();
            }


        } catch (SQLException e) {
            message("Błąd połączenia");
        }
    }


    public void editClass(Connection cnx, String typ, int LiczbaMiejsc, int DodatkoweWyp, int ID) {
        try {
            Statement stx = cnx.createStatement();
            int insertCount = stx.executeUpdate("UPDATE SALE SET SAL_TYP='"+typ+"', SAL_LICZBA_MIEJSC="+LiczbaMiejsc+", SAL_DODATKOWE_WYP="+DodatkoweWyp+" WHERE SAL_ID="+ID+";");
            message("Edytowano sale");
        } catch (SQLException e) {
            message("abc");
        }
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classedit);
        Connection cnx = MainActivity.cnx;
        View l1 = findViewById(R.id.Layout1);
        l1.setVisibility(View.INVISIBLE);
        View l2 = findViewById(R.id.Layout2);
        l2.setVisibility(View.INVISIBLE);
        View l3 = findViewById(R.id.Layout3);
        l3.setVisibility(View.INVISIBLE);
        ShowClasses(cnx);
        findViewById(R.id.EditClass_EditBegin_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            View b = findViewById(R.id.EditClass_EditBegin_Button);
                            b.setVisibility(View.INVISIBLE);
                            View l1 = findViewById(R.id.Layout1);
                            l1.setVisibility(View.VISIBLE);
                            View l2 = findViewById(R.id.Layout2);
                            l2.setVisibility(View.VISIBLE);
                            View l3 = findViewById(R.id.Layout3);
                            l3.setVisibility(View.VISIBLE);
                    }
                });
        findViewById(R.id.EditClass_EditEnd_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        View b = findViewById(R.id.EditClass_EditBegin_Button);
                        Connection cnx = MainActivity.cnx;
                        Spinner spinnerTyp = (Spinner) findViewById(R.id.ClassEdit_Type_Combo);
                        String typ = spinnerTyp.getSelectedItem().toString();
                        Spinner spinnerWyp = (Spinner) findViewById(R.id.ClassEdit_Wyp_Combo);
                        String wyp = spinnerWyp.getSelectedItem().toString();
                        Spinner spinnerMiejsca = (Spinner) findViewById(R.id.ClassEdit_Number_Combo);
                        String ilePom = spinnerMiejsca.getSelectedItem().toString();
                        int ile = Integer.parseInt(ilePom);
                        int wypos=0;
                        if(wyp.equals("Tak"))
                            wypos=1;
                        Spinner spinnerSala = (Spinner) findViewById(R.id.EditClass_Types_Spinner);
                        String Sala = spinnerSala.getSelectedItem().toString();
                        String idSaliString=Sala.substring(1,Sala.indexOf(']'));
                        int idSali = Integer.parseInt(idSaliString);
                        editClass(cnx,typ,ile,wypos,idSali);
                        ShowClasses(cnx);
                        b.setVisibility(View.VISIBLE);
                    }
                });
        findViewById(R.id.mainMenu_Close_Button3).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.students_MainMenu_Button2).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(ClassEditActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });


    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
