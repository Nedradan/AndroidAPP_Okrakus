package com.example.okrakusmobile;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TeacherEditActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(TeacherEditActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }

    public void ShowTeacherGroup(Connection cnx) {
        String NazwaTeachera="";
        String Stopien="";
        try {
            Statement stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT OSO_ID,OSO_IMIE,OSO_NAZWISKO,OSO_TYTUL FROM OSOBY WHERE OSO_STATUS='Wykladowca'");
            Spinner spinner = (Spinner) findViewById(R.id.TeacherEdit_Teacher_Spinner);
            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spinnerAdapter);
            while (rs.next()) {
                Stopien=rs.getString("OSO_TYTUL");
                if (rs.wasNull())
                    Stopien="";
                NazwaTeachera = "ID:[" + rs.getInt("OSO_ID") + "] "+""+Stopien+" " + rs.getString("OSO_IMIE") + " " + rs.getString("OSO_NAZWISKO");
                spinnerAdapter.add(NazwaTeachera);
                spinnerAdapter.notifyDataSetChanged();
            }
        } catch (SQLException e) {
            message("Błąd polączenia1");
        }
        }

    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager =(InputMethodManager)getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public void editTeacher(Connection cnx,int id, String Imie,String Nazwisko,String stopien){
            try {
                Statement stx = cnx.createStatement();
                String sqlQuery="UPDATE OSOBY SET OSO_IMIE ='"+Imie+"',OSO_NAZWISKO='"+Nazwisko+"',OSO_TYTUL='"+stopien+"' WHERE OSO_ID="+id+";";
                stx.executeUpdate(sqlQuery);

            message("Edytowano Wykładowce");
        } catch (SQLException e) {
            message("Wystąpił błąd");
        }
    }







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_teacher);
        ShowTeacherGroup(MainActivity.cnx);
        EditText imieInput = (EditText) findViewById(R.id.TeacherEdit_Name_Input);
        EditText nazwiskoInput = (EditText) findViewById(R.id.TeacherEdit_Surname_Input);
        View l1 = findViewById(R.id.TeacherLayout1);
        l1.setVisibility(View.INVISIBLE);
        findViewById(R.id.TeacherEdit_Begin_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        View b = findViewById(R.id.TeacherEdit_Begin_Button);
                        b.setVisibility(View.INVISIBLE);
                        View l1 = findViewById(R.id.TeacherLayout1);
                        l1.setVisibility(View.VISIBLE);

                    }
                });
        findViewById(R.id.TeacherEdit_End_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Connection cnx = MainActivity.cnx;
                        Spinner spinnerStopien= (Spinner) findViewById(R.id.TeacherEdit_Degree_Spinner);
                        String stopien = spinnerStopien.getSelectedItem().toString();
                        EditText imieInput = (EditText) findViewById(R.id.TeacherEdit_Name_Input);
                        EditText nazwiskoInput = (EditText) findViewById(R.id.TeacherEdit_Surname_Input);
                        Spinner spinnerTeacher = (Spinner) findViewById(R.id.TeacherEdit_Teacher_Spinner);
                        String Teacher = spinnerTeacher.getSelectedItem().toString();
                        String TeacherID=Teacher.substring(4,Teacher.indexOf(']'));
                        int idTeacheraINT = Integer.parseInt(TeacherID);

                        if(imieInput.length()!=0 && imieInput.length()<31) {
                            String imie = imieInput.getText().toString();
                            if(nazwiskoInput.length()!=0 && nazwiskoInput.length()<46)
                            {
                                String nazwisko = nazwiskoInput.getText().toString();
                                editTeacher(cnx,idTeacheraINT,imie,nazwisko,stopien);
                                ShowTeacherGroup(cnx);
                                imieInput.setText("");
                                nazwiskoInput.setText("");
                                View b = findViewById(R.id.TeacherEdit_Begin_Button);
                                b.setVisibility(View.VISIBLE);
                                View l1 = findViewById(R.id.TeacherLayout1);
                                l1.setVisibility(View.INVISIBLE);
                            }else
                                message("Nazwisko puste lub zbyt długie(30 znakow max)");
                        }
                        else
                            message("Imie puste lub zbyt długie(30 znakow max)");




                    }
                });
        findViewById(R.id.mainMenu_Close_Button3).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.Teachers_MainMenu_Button2).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(TeacherEditActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        imieInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });
        nazwiskoInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });



    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
