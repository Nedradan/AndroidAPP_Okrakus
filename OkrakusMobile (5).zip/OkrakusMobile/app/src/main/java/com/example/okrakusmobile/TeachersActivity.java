package com.example.okrakusmobile;

import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;

public class TeachersActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_teachers);
        findViewById(R.id.MainMenu_Close_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.Students_MainMenu_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(TeachersActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        findViewById(R.id.Students_AddDeleteTeacher_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(TeachersActivity.this, TeacherAddDeleteActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        findViewById(R.id.Students_EditTeacher_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(TeachersActivity.this, TeacherEditActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        findViewById(R.id.Students_FindTeacher_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(TeachersActivity.this, FindStudentActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        findViewById(R.id.Students_TeacherToSubject_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {

                        Intent intent = new Intent(TeachersActivity.this, TeacherForSubjectActivity.class);
                        startActivityForResult(intent, 1);
                        finish();

                    }
                });

    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
