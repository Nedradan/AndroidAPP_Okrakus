package com.example.okrakusmobile;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

public class ClassaddActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(ClassaddActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }
    public void addClass(Connection cnx, String typ, int LiczbaMiejsc, int DodatkoweWyp) {
        try {
            Statement stx = cnx.createStatement();
            int insertCount = stx.executeUpdate("INSERT INTO SALE (SAL_TYP,SAL_LICZBA_MIEJSC,SAL_DODATKOWE_WYP) VALUES('" + typ + "','" + LiczbaMiejsc + "','" + DodatkoweWyp + "');");
            message("Dodano sale");
        } catch (SQLException e) {
            message("Wystąpił błąd");
        }
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classadd);
        findViewById(R.id.ClassAdd_Add_Button).setOnClickListener(
                new android.view.View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            java.sql.Connection cnx = MainActivity.cnx;
                            Spinner spinnerTyp = (Spinner) findViewById(R.id.ClassAdd_Type_Combo);
                            String typ = spinnerTyp.getSelectedItem().toString();
                            Spinner spinnerWyp = (Spinner) findViewById(R.id.ClassAdd_Wyp_Combo);
                            String wyp = spinnerWyp.getSelectedItem().toString();
                            Spinner spinnerMiejsca = (Spinner) findViewById(R.id.ClassAdd_Number_Combo);
                            String ilePom = spinnerMiejsca.getSelectedItem().toString();
                            int ile = Integer.parseInt(ilePom);
                            int wypos=0;
                            if(wyp.equals("Tak"))
                                wypos=1;
                            addClass(cnx,typ,ile,wypos);
                    }
                });
        findViewById(R.id.mainMenu_Close_Button3).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.students_MainMenu_Button2).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(ClassaddActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });


    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
