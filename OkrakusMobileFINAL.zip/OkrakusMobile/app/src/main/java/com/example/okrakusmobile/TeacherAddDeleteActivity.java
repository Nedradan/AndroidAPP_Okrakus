package com.example.okrakusmobile;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class TeacherAddDeleteActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(TeacherAddDeleteActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }

    public void ShowTeacher(Connection cnx) {
        String NazwaWykładowcy="";
        try {
            Statement stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT OSO_ID,OSO_IMIE,OSO_NAZWISKO FROM OSOBY WHERE OSO_STATUS='Wykladowca'");
            Spinner spinner = (Spinner) findViewById(R.id.TeacherDelete_Teacher_Spinner);
            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spinnerAdapter);
            while (rs.next()) {
                NazwaWykładowcy = "[" + rs.getInt("OSO_ID") + "] " + rs.getString("OSO_IMIE") + " " + rs.getString("OSO_NAZWISKO");
                spinnerAdapter.add(NazwaWykładowcy);
                spinnerAdapter.notifyDataSetChanged();
            }
        } catch (SQLException e) {
            message("Błąd polączenia");
        }
        }



    public void addTeacher(Connection cnx,String Imie,String Nazwisko,String Tytul){
        try {
            Statement stx = cnx.createStatement();
            int insertCount = stx.executeUpdate("INSERT INTO OSOBY (OSO_STATUS, OSO_IMIE, OSO_NAZWISKO,OSO_STYPENDIUM, OSO_TYTUL) VALUES('Wykladowca', '"+Imie+"', '"+Nazwisko+"',NULL,'"+Tytul+"');");
            message("Dodano Wykladowce");
        } catch (SQLException e) {
            message("Wystąpił błąd");
        }
    }

    public void deleteTeacher(Connection cnx,int id){
        try {
            Statement statement = cnx.createStatement();
            String sqlQuery="SELECT * FROM OSOBY WHERE OSO_ID='"+id+"' AND OSO_STATUS='Wykladowca'";
            ResultSet rs = statement.executeQuery(sqlQuery);
            int deleteCount1 = statement.executeUpdate("DELETE FROM WYKLADOWCY_PRZYDZIAL WHERE STU_OSO_ID="+id+";");
            int deleteCount2 = statement.executeUpdate("DELETE FROM OSOBY WHERE OSO_ID="+id+";");
            message( "Usunięto wykladowce!");
        }
        catch (SQLException e) {
           message("Błąd połączenia");

        }
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_teacher);
        ShowTeacher(MainActivity.cnx);
        findViewById(R.id.TeacherAdd_add_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            Connection cnx = MainActivity.cnx;
                            Spinner spinnerStopien = (Spinner) findViewById(R.id.TeacherAdd_Degree_Spinner);
                            String stopien = spinnerStopien.getSelectedItem().toString();
                            EditText imieInput = (EditText) findViewById(R.id.TeacherAdd_Name_Input);
                            EditText nazwiskoInput = (EditText) findViewById(R.id.TeacherAdd_Surname_Input);

                        if(imieInput.length()!=0 && imieInput.length()<31) {
                                String imie = imieInput.getText().toString();
                                if(nazwiskoInput.length()!=0 && nazwiskoInput.length()<46)
                                {
                                    String nazwisko = nazwiskoInput.getText().toString();
                                    addTeacher(cnx,imie,nazwisko,stopien);
                                    ShowTeacher(cnx);
                                }else
                                    message("Nazwisko puste lub zbyt długie(30 znakow max)");
                            }
                            else
                                message("Imie puste lub zbyt długie(30 znakow max)");

                    }
                });
        findViewById(R.id.TeacherDelete_delete_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Connection cnx = MainActivity.cnx;
                        Spinner spinnerWykladowca = (Spinner) findViewById(R.id.TeacherDelete_Teacher_Spinner);
                        String Wykladowca = spinnerWykladowca.getSelectedItem().toString();
                        String WykladowcaID=Wykladowca.substring(1,Wykladowca.indexOf(']'));
                        int idWykladowcyINT = Integer.parseInt(WykladowcaID);
                        deleteTeacher(cnx,idWykladowcyINT);
                        ShowTeacher(cnx);


                    }
                });
        findViewById(R.id.mainMenu_Close_Button3).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.students_MainMenu_Button2).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(TeacherAddDeleteActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });


    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
