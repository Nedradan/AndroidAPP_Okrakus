package com.example.okrakusmobile;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentFindActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(StudentFindActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }

    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager =(InputMethodManager)getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public void findTeacher(Connection cnx,int id, String Imie,String Nazwisko,String stypendium){
        if (stypendium.equals("Wszystkie"))
            stypendium="";
        String sqlQuery="";
        switch (id) {
            case -10:
            try {
                Statement stx = cnx.createStatement();
                sqlQuery="SELECT OSO_ID,OSO_IMIE,OSO_NAZWISKO OSO_STYPENDIUM FROM OSOBY WHERE OSO_STATUS LIKE 'Student'";
            } catch (SQLException e) {
                message("Wystąpił błąd");
            }
            break;
            case -2:
                try {
                    Statement stx = cnx.createStatement();
                    sqlQuery="SELECT OSO_ID,OSO_IMIE,OSO_NAZWISKO,OSO_STYPENDIUM FROM OSOBY WHERE OSO_STATUS LIKE 'Student' AND OSO_IMIE LIKE '"+Imie+"%' AND OSO_NAZWISKO LIKE '"+Nazwisko+"%' AND OSO_STYPENDIUM LIKE '"+stypendium+"%';";
                } catch (SQLException e) {
                    message("Wystąpił błąd");
                }
                break;
            default:
                try {
                    Statement stx = cnx.createStatement();
                    sqlQuery="SELECT OSO_ID,OSO_IMIE,OSO_NAZWISKO,OSO_STYPENDIUM FROM OSOBY WHERE OSO_STATUS LIKE 'Student' AND OSO_IMIE LIKE '"+Imie+"%' AND OSO_NAZWISKO LIKE '"+Nazwisko+"%' AND OSO_STYPENDIUM LIKE '"+stypendium+"%' AND OSO_ID="+id+";";

                } catch (SQLException e) {
                    message("Wystąpił błąd");
                }
                break;
        }

        try {

            TableLayout tl = (TableLayout) findViewById(R.id.StudentFind_TableLayout);

            int childCount = tl.getChildCount();
            if (childCount > 1) {
                tl.removeViews(1, childCount - 1);
            }
            Statement stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery(sqlQuery);
            if (rs.first()==false){
                message("Brak STUDENTA pasującego do podanych kryteriów");
                return;
            }
            rs.beforeFirst();
            while (rs.next()) {
                TableRow tr = new TableRow(this);
                TextView td0 = new TextView(this);
                TextView td1 = new TextView(this);
                TextView td2 = new TextView(this);
                TextView td3 = new TextView(this);

                td0.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                td1.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                td2.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);
                td3.setTextAlignment(View.TEXT_ALIGNMENT_CENTER);

                td0.setText(String.valueOf(rs.getInt("OSO_ID")));
                td1.setText(rs.getString("OSO_IMIE"));
                td2.setText(rs.getString("OSO_NAZWISKO"));
                td3.setText(rs.getString("OSO_STYPENDIUM"));

                tr.addView(td0);
                tr.addView(td1);
                tr.addView(td2);
                tr.addView(td3);

                tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
                tl.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));

            }
            TableRow tr = new TableRow(this);
            TextView td0 = new TextView(this);
            TextView td1 = new TextView(this);
            TextView td2 = new TextView(this);
            TextView td3 = new TextView(this);

            td0.setText("");
            td1.setText("");
            td2.setText("");
            td3.setText("");

            tr.addView(td0);
            tr.addView(td1);
            tr.addView(td2);
            tr.addView(td3);

            tr.setLayoutParams(new TableRow.LayoutParams(TableRow.LayoutParams.FILL_PARENT, TableRow.LayoutParams.WRAP_CONTENT));
            tl.addView(tr, new TableLayout.LayoutParams(TableLayout.LayoutParams.FILL_PARENT, TableLayout.LayoutParams.WRAP_CONTENT));
            message("Znaleziono rekordy pasujące");
        } catch (SQLException e) {
            message( "Wystąpił problemm");
        }


    }







    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_find_student);
        EditText imieInput = (EditText) findViewById(R.id.StudentFind_Name_Input);
        EditText nazwiskoInput = (EditText) findViewById(R.id.StudentFind_Surname_Input);
        EditText IdInput = (EditText) findViewById(R.id.StudentFind_ID_Input);
        findViewById(R.id.StudentFind_Show_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Connection cnx = MainActivity.cnx;
                        Spinner spinnerstypendium= (Spinner) findViewById(R.id.StudentFind_Groups_Spinner);
                        String stypendium = spinnerstypendium.getSelectedItem().toString();
                        EditText imieInput = (EditText) findViewById(R.id.StudentFind_Name_Input);
                        EditText nazwiskoInput = (EditText) findViewById(R.id.StudentFind_Surname_Input);
                        EditText IdInput = (EditText) findViewById(R.id.StudentFind_ID_Input);
                        String nazwisko = nazwiskoInput.getText().toString();
                        String imie = imieInput.getText().toString();
                        String idString = IdInput.getText().toString();
                        int IDInt=-1;
                        if(imie=="" &&nazwisko==""&&idString==""&&stypendium=="Wszystkie")
                            IDInt=-10;
                        else if(!idString.equals("")) {
                            try {
                                IDInt = Integer.parseInt(idString);
                            } catch (NumberFormatException e) {
                                message("W polu ID nie została wpisana liczba!");
                                IdInput.setText("");
                            }
                        }else
                            IDInt=-2;
                        if (IDInt!=-1)
                        {
                            findTeacher(cnx,IDInt,imie,nazwisko,stypendium);
                            imieInput.onEditorAction(EditorInfo.IME_ACTION_DONE);
                            nazwiskoInput.onEditorAction(EditorInfo.IME_ACTION_DONE);
                            IdInput.onEditorAction(EditorInfo.IME_ACTION_DONE);

                            imieInput.setText("");
                            nazwiskoInput.setText("");
                            IdInput.setText("");
                        }





                    }
                });
        findViewById(R.id.mainMenu_Close_Button3).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.students_MainMenu_Button2).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(StudentFindActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        imieInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });
        nazwiskoInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });
        IdInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });




    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
