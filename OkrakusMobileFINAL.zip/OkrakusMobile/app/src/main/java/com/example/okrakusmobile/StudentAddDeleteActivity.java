package com.example.okrakusmobile;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class StudentAddDeleteActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(StudentAddDeleteActivity.this).create();
        alertDialog.setTitle("Alert");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }

    public void ShowStudentGroup(Connection cnx) {
        String NazwaStudenta="";
        String NumerGrupy="";
        String Stypendium="";
        try {
            Statement stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT OSO_ID,OSO_IMIE,OSO_NAZWISKO,OSO_STYPENDIUM FROM OSOBY WHERE OSO_STATUS='Student'");
            Spinner spinner = (Spinner) findViewById(R.id.StudentDelete_Student_Spinner);
            ArrayAdapter<String> spinnerAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
            spinnerAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner.setAdapter(spinnerAdapter);
            while (rs.next()) {
                Stypendium=rs.getString("OSO_STYPENDIUM");
                if (rs.wasNull())
                    Stypendium="Brak";
                NazwaStudenta = "[" + rs.getInt("OSO_ID") + "] " + rs.getString("OSO_IMIE") + " " + rs.getString("OSO_NAZWISKO")+"[S: "+Stypendium+"]";
                spinnerAdapter.add(NazwaStudenta);
                spinnerAdapter.notifyDataSetChanged();
            }
            rs = stmt.executeQuery("SELECT GRU_ID FROM GRUPY_ST");
            Spinner spinner3 = (Spinner)findViewById(R.id.StudentAdd_Group_Spinner);
            ArrayAdapter<String> spinnerAdapter3 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
            spinnerAdapter3.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner3.setAdapter(spinnerAdapter3);
            while (rs.next()) {
                NumerGrupy=""+rs.getInt("GRU_ID");
                spinnerAdapter3.add(NumerGrupy);
                spinnerAdapter3.notifyDataSetChanged();
            }
        } catch (SQLException e) {
            message("Błąd polączenia1");
        }
        }

    public void hideKeyboard(View view) {
        InputMethodManager inputMethodManager =(InputMethodManager)getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(view.getWindowToken(), 0);
    }

    public void addStudent(Connection cnx,String Imie,String Nazwisko,String Stypendium,int GrupaID){
        try {
            Statement stx = cnx.createStatement();
            int insertCount = stx.executeUpdate("INSERT INTO OSOBY (OSO_STATUS, OSO_IMIE, OSO_NAZWISKO,OSO_STYPENDIUM) VALUES('Student', '" + Imie + "', '" + Nazwisko + "' , '" + Stypendium + "');");
            ResultSet rs = stx.executeQuery("SELECT MAX(OSO_ID) FROM OSOBY");
            rs.first();
            int insertGroup = stx.executeUpdate("INSERT INTO STUDENCI_PRZYDZIAL VALUES ('"+rs.getInt("MAX(OSO_ID)")+"','"+GrupaID+"');");
            message("Dodano Studenta");
        } catch (SQLException e) {
            message("Wystąpił błąd");
        }
    }

    public void deleteStudent(Connection cnx,int id){
        try {
            Statement statement = cnx.createStatement();
            int deleteCount1 = statement.executeUpdate("DELETE FROM STUDENCI_PRZYDZIAL WHERE STU_OSO_ID="+id+";");
            int deleteCount2 = statement.executeUpdate("DELETE FROM OSOBY WHERE OSO_ID="+id+";");
            message( "Usunięto Studenta!");
        }
        catch (SQLException e) {
           message("Błąd połączenia");

        }
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_delete_studentr);
        ShowStudentGroup(MainActivity.cnx);
        EditText imieInput = (EditText) findViewById(R.id.StudentAdd_Name_Input);
        EditText nazwiskoInput = (EditText) findViewById(R.id.StudentAdd_Surname_Input);
        findViewById(R.id.StudentAdd_add_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            Connection cnx = MainActivity.cnx;
                            Spinner spinnerStypednium= (Spinner) findViewById(R.id.StudentAdd_Money_Spinner);
                            String stypendium = spinnerStypednium.getSelectedItem().toString();
                            EditText imieInput = (EditText) findViewById(R.id.StudentAdd_Name_Input);
                            EditText nazwiskoInput = (EditText) findViewById(R.id.StudentAdd_Surname_Input);
                            Spinner spinnerGrupy = (Spinner) findViewById(R.id.StudentAdd_Group_Spinner);
                            String Grupa = spinnerGrupy.getSelectedItem().toString();
                            int idGrupyINT = Integer.parseInt(Grupa);
                        if(imieInput.length()!=0 && imieInput.length()<31) {
                                String imie = imieInput.getText().toString();
                                if(nazwiskoInput.length()!=0 && nazwiskoInput.length()<46)
                                {
                                    String nazwisko = nazwiskoInput.getText().toString();
                                    addStudent(cnx,imie,nazwisko,stypendium,idGrupyINT);
                                    ShowStudentGroup(cnx);
                                    imieInput.setText("");
                                    nazwiskoInput.setText("");
                                }else
                                    message("Nazwisko puste lub zbyt długie(30 znakow max)");
                            }
                            else
                                message("Imie puste lub zbyt długie(30 znakow max)");

                    }
                });
        findViewById(R.id.StudentDelete_delete_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Connection cnx = MainActivity.cnx;
                        Spinner spinnerStudent = (Spinner) findViewById(R.id.StudentDelete_Student_Spinner);
                        String Student = spinnerStudent.getSelectedItem().toString();
                        String StudentID=Student.substring(1,Student.indexOf(']'));
                        int idStudentaINT = Integer.parseInt(StudentID);
                        deleteStudent(cnx,idStudentaINT);
                        ShowStudentGroup(cnx);


                    }
                });
        findViewById(R.id.mainMenu_Close_Button3).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.students_MainMenu_Button2).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(StudentAddDeleteActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });
        imieInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });
        nazwiskoInput.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View v, boolean hasFocus) {
                if (!hasFocus) {
                    hideKeyboard(v);
                }
            }
        });



    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
