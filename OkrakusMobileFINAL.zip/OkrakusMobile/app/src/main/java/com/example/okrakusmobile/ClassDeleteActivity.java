package com.example.okrakusmobile;

import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ClassDeleteActivity extends AppCompatActivity {

    public void message(String wiadomosc){
        AlertDialog alertDialog = new AlertDialog.Builder(ClassDeleteActivity.this).create();
        alertDialog.setTitle("");
        alertDialog.setMessage(wiadomosc);
        alertDialog.setButton(AlertDialog.BUTTON_NEUTRAL, "OK",
                new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        dialog.dismiss();
                    }


                });
        alertDialog.show();
    }
    public void ShowClasses(Connection cnx) {
        String NazwaKlasy="";
        try {
            Statement stmt = cnx.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT SAL_ID,SAL_TYP,SAL_LICZBA_MIEJSC,SAL_DODATKOWE_WYP FROM SALE");
            Spinner spinner2 = (Spinner)findViewById(R.id.deleteClass_Types_Spinner);
            ArrayAdapter<String> spinnerAdapter2 = new ArrayAdapter<String>(this, android.R.layout.simple_spinner_item, android.R.id.text1);
            spinnerAdapter2.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
            spinner2.setAdapter(spinnerAdapter2);
            while (rs.next()) {
                int idSaliINT=rs.getInt("SAL_ID");
                String idSali=String.valueOf(idSaliINT);
                int iloscMiejscINT=rs.getInt("SAL_LICZBA_MIEJSC");
                String iloscMiejsc=String.valueOf(iloscMiejscINT);
                int wypos=rs.getInt("SAL_DODATKOWE_WYP");
                String dodatkoweWyp="Dodatkowe wyposażenie";
                if(wypos==0)
                    dodatkoweWyp="Brak wyposażenia";
                NazwaKlasy="["+idSali+"] ["+rs.getString("SAL_TYP")+"] [Miejsca: "+iloscMiejsc+"] ["+dodatkoweWyp+"]";
                spinnerAdapter2.add(NazwaKlasy);
                spinnerAdapter2.notifyDataSetChanged();
            }


        } catch (SQLException e) {
            message("abc");
        }
    }





    public void deleteSubject(Connection cnx, int ID ) {
        try {
            Statement stx = cnx.createStatement();
            int insertCount = stx.executeUpdate("DELETE FROM SALE WHERE SAL_ID=" + ID + ";");
            message("USUNIĘTO SALE");
        } catch (SQLException e) {
            message("Wystąpił błąd");
        }
    }





    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_classdelete);
        Connection cnx = MainActivity.cnx;
        ShowClasses(cnx);
        findViewById(R.id.deleteClass_delete_Button).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                            Spinner spinnerSala = (Spinner) findViewById(R.id.deleteClass_Types_Spinner);
                            String Sala = spinnerSala.getSelectedItem().toString();
                            String idSaliString=Sala.substring(1,Sala.indexOf(']'));
                            int idSali = Integer.parseInt(idSaliString);
                            deleteSubject(MainActivity.cnx,idSali);
                            ShowClasses(MainActivity.cnx);

                    }
                });
        findViewById(R.id.mainMenu_Close_Button3).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        finish();
                        System.exit(0);
                    }
                });
        findViewById(R.id.students_MainMenu_Button2).setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        Intent intent = new Intent(ClassDeleteActivity.this, MainActivity.class);
                        startActivityForResult(intent, 1);
                        finish();
                    }
                });


    }






    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
}
